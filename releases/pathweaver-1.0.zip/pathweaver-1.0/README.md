# PathWeaver
PathWeaver is an API for creating path-networks like road- or traffic-networks. It offers method like computing shortest paths.

The available documentation can be found in [our wiki](https://github.com/ZabuzaW/PathWeaver/wiki).
